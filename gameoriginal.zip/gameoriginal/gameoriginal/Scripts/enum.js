this.ColorEnum = {
	RED : 0,
	GREEN : 1,
    BLUE : 2,   
}